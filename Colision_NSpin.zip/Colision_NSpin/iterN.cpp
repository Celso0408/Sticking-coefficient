#include "iterN.h"

static int *NS_;
static int *NN_;

// Populating the primitive base; 
void Populate_N(int N, int *dimen_){  // DIMEN = DIM(N-1);
int nq_past = (N-1+2)+1;
//computaional bases:
// Operations Sulth |Q  |_N <= 	|Q |_(N-1)
// Operations North |Q+1|_N <= 	|Q |_(N-1)
for(int q = 0; q < nq_past; q++){
		int dim = dimen_[q];
		NS_[q] += dim;
		NN_[q+1] += dim; 
}
}

int find_charge(int q, int genre){
  int r = -1;
  if (genre == 0){ 						// Sulth
	r = q;
  }
  else{	
      if(genre == 1){					        // North
           r = q - 1;
      }	
  }
  return r;
}

int find_father(int q, int genre, int p, int *NS_){
  int r = -1;
  if (genre == 0){ 						// Sulth
	r = p; 
  }
  else{	
	if(genre == 1){					        // North
		r = p - NS_[q];
	}
  }
return r;
}  



// THE FUNCTION TO SOLVE THE ITERACTION N. 

void iterN_1(int N, int *dimen_p_, int *dimen_, int z){
//std::cout << "Diagonalization process for 'H1' N=" << N << " is starting now..."  << std::endl;

int nq = (N+2)+1;
// Creating the Basis and Making all matrix elements zero.
NS_ = new int[nq];
NN_ = new int[nq];
for(int i=0; i< nq; i++){
	NS_[i] = 0;
	NN_[i] = 0;
}

Populate_N(N, dimen_p_);

double lamb_ = lamb();								    	                                                        // Reading Lambda from parameters.txt.
double D_N = (1-pow(lamb_, (float) -1))*(pow(lamb_, (float) -(N-1)/2))/log(lamb_);	                                                        // D_N
double t_N = (1-pow(lamb_,(float) -N-2))/sqrt((1-pow(lamb_,(float) -2*(N-1)-1))*(1-pow(lamb_,(float) -2*(N-1)-3)));				// Calculating the coupling t_(N-1).

// Creating here the pointer to hamiltonian sector (q). 
double **HN_ = new double*[nq];

#pragma omp parallel for
for(int q = 0; q < nq; q++){
		int dim = NS_[q] + NN_[q];
		if (dim > 0){
			HN_[q] = new double[(long) (dim+1)*dim/2];			// Allocating memory to sector (q,ds).
                        for(int p2=0; p2 < dim; p2++){
			      for(int p1=0; p1<= p2; p1++){
				    int g1 = genre(q,p1+1, NS_, NN_);			        // g1(p1)
				    int g2 = genre(q,p2+1, NS_, NN_);			        // g2(p2)
                                    int q1 = find_charge(q,g1);                                
                                    int r1 = find_father(q,g1,p1+1,NS_);
                                    int q2 = find_charge(q,g2);                                
                                    int r2 = find_father(q,g2,p2+1,NS_);
                                    // std::cout << "|" << q << " , " << p2 << " , " << g2  << "| ... |" << q2 << " , " << r2 << " , " << g2 << "|" << std::endl;
                                    int dim1 = dimen_p_[q1];				
				    int dim2 = dimen_p_[q2];
				    long k_mel_1 = (r2-1)*dim1+(r1-1);
				    long k_mel_2 = (r1-1)*dim2+(r2-1); 
				    long k = (p2*(p2+1)/2) + p1; 			// Memory address starting in k=0;
                                    HN_[q][k] = 0; 
					if ((g1==g2)&&(q1==q2)&&(r1==r2)){			// Diagonal terms.
					  HN_[q][k]= sqrt(lamb_)*eigen_erg_read(q1,(long) r1-1);  	// Att, scaled H
					}
					if ((g2==0)&&(g1==1)){						// SN terms.
					  HN_[q][k] = t_N*mel_read(q1,k_mel_1);
					}
					if ((g2==1)&&(g1==0)){						// NS terms. 
					  HN_[q][k] = t_N*mel_read(q2,k_mel_2);
					}					
                              }
                        }	
		} // end if dim> 0	
} // end for q

eigen_delete(N-1,dimen_p_);  // Delete all elements saved in eigen matrix
//eigen_vect_delete(N-1,dimen_p_); // Delete all elements saved in eigen matrix
mel_delete(N-1,dimen_p_); // Delete all elements saved in mel

eigen_start(N);

// Ok. The Hamiltonian is ready to diagonalization process. 
for (int q=0; q < nq; q++) {
		int dim = NS_[q]+ NN_[q];
		dimen_[q] = dim;                                                                // Save the Dim[q]
		if(dim > 0) {
			double *eigen_values = new double[dim];                         	// Matrix to find the E-Energies
			double **eigen_vectors = new double*[dim];		               	// Matrix to find the E-Vectors
			for (int k=0; k<dim; k++) {
				eigen_vectors[k] = new double[dim];
			}
			long Nel_max = (1+dim)*dim/2;	                      		        // Maximum number of elements of LTM
			double* Hamiltonian  = new double[Nel_max];                     	// H[q] to use in diagonalization
			for (long k=0; k<Nel_max; k++) {					// Save the values to diagolize
				Hamiltonian[k] = HN_[q][k];
			}
			delete[] HN_[q];					        // Delete the HN in the sector (q)
			int ret = givens(dim, dim , Hamiltonian , eigen_values, eigen_vectors, 0);// Solve the hamiltonian
			delete[] Hamiltonian;
			Hamiltonian = NULL;										        
			eigen_erg_alloc_memory(q,(long) dim);			                // Alloc memory to save E-Energies
			eigen_vect_alloc_memory(q,(long) dim*dim);			        // Alloc memory to save E-Vectors
			for (long k=0; k < dim; k++) {
				eigen_erg_write(q,k,eigen_values[k]);
			}
			for (int i=0; i < dim ; i++) {						// Line 0, 1... dim_cut_off
				int signal = 1;
				if (eigen_vectors[i][0] < 0){
					signal = -1;
				}
				else{
					if((eigen_vectors[i][0] == 0)&&(eigen_vectors[i][1]<0)){
						signal = -1;						
					}
				}
				for (int j=0; j<dim; j++) { 					// Collum 0, 1 ... dim
					eigen_vect_write(q,(long) i*dim+j, (double) signal*eigen_vectors[i][j]); 
				}
				
			}
			delete[] eigen_values;
			eigen_values = NULL;
			for (int i=0; i< dim; i++) {
				delete[] eigen_vectors[i];
			}
			delete[] eigen_vectors;
			eigen_vectors= NULL;
		} //end if dim > 0
} // end for q
delete[] HN_;
HN_ = NULL;

// Printing the eigen energies and eigen vectors
std::cout << std::setprecision(12) << std::fixed;
for (int q=0; q < nq; q++) {
		int dim = dimen_[q];
		if((dim > 0)&&(q == int (N+4)/2 )) {
			//std::cout << "["<< q << "] Sector"<< '\t' <<"dim ="<< dim;
			//std::cout << ";  Eigen values (Escaled): ";
			//for (long k=0; k<dim; k++) {
				//double Energy = D_N*eigen_erg_read(q,k);
				//std::cout << "E[" << k+1 << "]=";
				//std::cout << Energy << ";";       // Scaled results         
			//}
                        if ((N == fN_max())&&(z==0)){
				std::ofstream file;
				file.open("0_Energies_L_"+std::to_string(z)+".txt");
				//Saving the Energies
				for (long k=0; k<dim; k++) {
					double Energy = E_d() + D_N*(eigen_erg_read(q,k));        
					file << std::setprecision(18) << Energy;
					file << std::endl;
				}
  				//Closing the file
  				file.close();
			}			
			/*  Printing The Vectors.
			std::cout << std::endl << "Eigen vectors matrix:" << std::endl;
			for (int i=0; i<dim; i++) {
				std::cout << '\t';
				for (int j=0; j<dim_t; j++) {
					long k =i*dim +j;
					double vector = eigen_vect_read(q,ds,k);
					std::cout << vector << "; ";
				}
				std::cout << std::endl;
			}
			// */                        
			std::cout << std::endl;
		}// end if dim>0
}//end for q

if(N < fN_max()){

mel_start(N);
//|Q+1 dS+1 r2|(f_N^+)|Q dS r1| = sum_{p2,p1} U*(Q+1;dS+1)[r2,p2]U(Q;S)[r1,p1]*|Q+1 dS+1 p2|(f_N^+)|Q dS p1|
for(int q=0;q<(nq-1);q++){
		int dim = dimen_[q];
		int dim2 = dimen_[q+1]; 
		if (dim*dim2>0){
			int N11 = NS_[q];		// Sup limit for g1 = 0
			int N12 = N11 + NN_[q]; 	// Sup limit for g1 = 1
			int N21 = NS_[q+1];             // Sup Limit for g2 = 0
			int N22 = N21 + NN_[q+1];	// Sup Limit for g2 = 1
			mel_alloc_memory(q,(long) dim*dim2);						// 
			#pragma omp parallel for
			for(long k=0;k<dim*dim2;k++){
				double sum = 0;
				int r2 = k/dim;      						// line
				int r1 = k - r2*dim; 						// Collum
				for(int p1=0; p1<N11; p1++){ 			// g1(p1) = 0;	// g2(p2) = 1;
					int p2 = p1 + N21;
					if (p2<N22){						// delta(l1,l2)
						double aux2=eigen_vect_read(q+1,(long)r2*N22 +p2);
						double aux1=eigen_vect_read(q,(long)r1*N12+p1);
						sum += aux2*aux1;
					}						
				}
				mel_write(q,k,sum);
			} //end for k
		} // end if dim*dim2
} // end for q

}
 
delete[] NS_;
delete[] NN_;
NS_ = NULL;
NN_ = NULL;


}
