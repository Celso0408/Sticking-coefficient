#include "param.h"
#include <cmath>
#include "giv0.h"
#include "mel.h"
#include <iostream>
#include <iomanip>
#include <omp.h>
#include "iterd.h"

void iterN_1(int N, int *dimen_, int *dimen_out_, int z);
int find_charge(int q, int genre);
int find_father(int q, int genre, int p, int *NS_);
