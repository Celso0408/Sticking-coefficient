from __future__ import division
import matplotlib
import warnings
import numpy as np
from pylab import * 
from numpy import *
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
import matplotlib.pyplot as plt
import matplotlib.text as text
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.cm as cm
from matplotlib.colors import LightSource
from matplotlib import rcParams
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from matplotlib.offsetbox import AnchoredOffsetbox
from matplotlib.patches import FancyArrowPatch
#hold(True)
out_file_name='SLProj_z=2_.pdf'
rc('text', usetex=True)
rcParams['font.serif'] = ['Helvetica']
rcParams.update({'font.size': 12})
ccolor='Blues'
minor_locator = MultipleLocator(2)
ratio=0.421
subplots_adjust(left=0.12,right=0.95,top=0.94,bottom=0.13,wspace=0.01,hspace=0.4)
tickssize=5
labelsize='12'
textsize='12'
tickslen=3

xmin=0 - 50
xmax=405
ymin=0 - 0.03
ymax=1*1.02
ystep=0.001
xstep=100

minorLocatorx   = MultipleLocator(xstep/10)
minorLocatory   = MultipleLocator(ystep/10)
ty = arange(ymin,ymax,ystep)
tx = arange(xmin,xmax,xstep)

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ax1 = plt.subplot()

plt.title(r'$z=2$', size=20,style='normal')

b1=loadtxt('0_Projections_360.txt')
a2=loadtxt('0_Energies_R_360.txt')

Ein = 2.71573225654593831 - 0.05
Ew = -2.00
#a11=loadtxt('Projections(1).txt')
#a12=loadtxt('Energies_L(1).txt')

#a21=loadtxt('Projections(2).txt')
#a22=loadtxt('Energies_L(2).txt')

#a31=loadtxt('Projections(3).txt')
#a32=loadtxt('Energies_L(3).txt')

#a41=loadtxt('Projections(4).txt')
#a42=loadtxt('Energies_L(4).txt')

#a51=loadtxt('Projections(5).txt')
#a52=loadtxt('Energies_L(5).txt')

step_e = 200

#for i in range(0,len(a12[:])):
#    if (a12[i] <= step_e): z1 = i

#for i in range(0,len(a22[:])):
#    if (a22[i] <= step_e): k2 = i
#    if (a22[i] <= 2*step_e): z2 = i

#for i in range(0,len(a32[:])):
#    if (a32[i] <= 2*step_e): k3 = i
 #   if (a32[i] <= 3*step_e): z3 = i

#for i in range(0,len(a42[:])):
 #   if (a42[i] <= 3*step_e): k4 = i
#    if (a42[i] <= 4*step_e): z4 = i

#for i in range(0,len(a52[:])):
#    if (a52[i] <= 4*step_e): k5 = i
#    if (a52[i] <= 5*step_e): z5 = i

#dim_total = (z1+1) + (z2 - k2) + (z3 - k3) + (z4 - k4) + (z5 - k5)
#print(dim_total)

#new_a2 = np.zeros(dim_total)
#new_a1 = np.zeros(dim_total)

#for i in range(0,z1+1):
 #   new_a1[i] = a11[i]
 #   new_a2[i] = a12[i]

#li = z1 + 1
#ls = li + z2 - k2

#for i in range(li,ls):
#    z = i - li+ k2 + 1
#    new_a1[i] = a21[z]
#    new_a2[i] = a22[z]
   
#li = ls
#ls = li + (z3 - k3)

#for i in range(li,ls):
#    z = i - li+ k3 + 1
#    new_a1[i] = a31[z]
#    new_a2[i] = a32[z]
#  
#li = ls
#ls = li + (z4 - k4)

#for i in range(li,ls):
 #   z = i - li+ k4 + 1
 #   new_a1[i] = a41[z]
 #   new_a2[i] = a42[z]
    
#li = ls
#ls = li + (z5 - k5)

#for i in range(li,ls):
 #   z = i - li+ k5 + 1
 #   new_a1[i] = a51[z]
 #   new_a2[i] = a52[z]


tam = len(a2)
a1 = np.zeros(tam)

for i in range(0,tam): 
		a1[i] = b1[i]

#xmin = 1185
#xmax= 1380

ax1.set_xlim(-1.01,1.51)
ax1.set_ylim(-0.025,1.01)


line1= ax1.plot([0*Ein,0*Ein],[0,1])
setp(line1, linestyle="--", color='black', marker='none', markerfacecolor='none', linewidth=0.5, markersize=1.25, markevery=1)

line1= ax1.plot([Ew,Ew],[0,1])
setp(line1, linestyle="--", color='blue', marker='none', markerfacecolor='none', linewidth=0.5, markersize=1.25, markevery=1)

#line1= ax1.plot([En,En],[0,1])
#setp(line1, linestyle="--", color='red', marker='none', markerfacecolor='none', linewidth=0.5, markersize=1.25, markevery=1)

line1= ax1.plot(Ein + a2[:],np.abs(a1[:]))
setp(line1, linestyle="None", color='black', marker='d', markerfacecolor='none', markeredgewidth=2.5, markersize=2.5, markevery=1)

#line1= ax1.plot(E0 + DN*a2[:],np.abs(a1[:]),label = r'Block Diagonal Approximation')
#setp(line1, linestyle="None", color='black', marker='d', markerfacecolor='none', markeredgewidth=1.25, markersize=1.25, markevery=1)



#line1= ax1.plot(E0 + DN*a2[:],np.abs(new_a2[:]-a2[:]),label = r'')
#setp(line1, linestyle="None", color='black', marker='d', markerfacecolor='none', markeredgewidth=1.25, markersize=1.25, markevery=1)
#line1= ax1.plot(-3.471219300549 + DN*a2[:],10*DN**2 + 0*np.abs(new_a1[:]-a1[:]),label = r'')
#setp(line1, linestyle="--", color='black', marker='none', markerfacecolor='none', markeredgewidth=1.25, markersize=1.25, markevery=1)

ax1.set_ylabel(r'$|\langle \varphi_n | \Phi_0 \rangle |$', size=20,style='normal')
#ax1.set_ylabel(r'$\mathrm{Error}(E_n)$', size=20,style='normal')

ax1.set_xlabel(r'$\textbf{E}_{{n}}/D$', size=17,style='normal')


#ax1.legend(fontsize = 14, shadow = False, frameon=False,prop={'size':14}, labelspacing=0.2,ncol=1,columnspacing=0.2,handletextpad=0.1)
ax1.tick_params(which='major',direction='in', axis='y',labelsize=labelsize, length=tickssize, width=0.8 )
ax1.tick_params(which='minor',direction='in', axis='y',labelsize=labelsize, length=tickssize/2, width=0.5)
ax1.tick_params(which='major',direction='in', axis='x',labelsize=labelsize, length=tickssize, width=1.2, pad=6 )
ax1.tick_params(which='minor',direction='in', axis='x',labelsize=labelsize, length=tickssize/2, width=0.5)
ax1.minorticks_on()
ax1.yaxis.set_major_locator(MultipleLocator(0.2))
ax1.xaxis.set_major_locator(MultipleLocator(0.5))

savefig(out_file_name)
