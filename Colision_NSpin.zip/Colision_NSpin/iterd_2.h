#include <cmath>
#include "param.h"
#include "giv0.h"
#include "mel.h"
#include <new>
#include "iterd.h"

void iter0_2(double V, double W);
