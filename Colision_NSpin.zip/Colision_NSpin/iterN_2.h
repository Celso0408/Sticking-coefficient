#include "param.h"
#include <cmath>
#include "giv0.h"
#include "mel.h"
#include <iostream>
#include <iomanip>
#include <omp.h>
#include "iterd.h"
#include "iterN.h"


void iterN_2(int N, int *dimen_, int *dimen_out_, int z);
