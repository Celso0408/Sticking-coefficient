from __future__ import division
import matplotlib
import warnings
import numpy as np
from pylab import * 
from numpy import *
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
import matplotlib.pyplot as plt
import matplotlib.text as text
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.cm as cm
from matplotlib.colors import LightSource
from matplotlib import rcParams
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from matplotlib.offsetbox import AnchoredOffsetbox
from matplotlib.patches import FancyArrowPatch
#hold(True)
out_file_name='Eletronic_potentials.pdf'
rc('text', usetex=True)
rcParams['font.serif'] = ['Helvetica']
rcParams.update({'font.size': 12})
ccolor='Blues'
minor_locator = MultipleLocator(2)
ratio=0.421
subplots_adjust(left=0.10,right=0.98,top=0.96,bottom=0.12,wspace=0.01,hspace=0.4)
tickssize=10
labelsize='10'
textsize='16'
tickslen=10
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ax1 = plt.subplot()

#plt.title(r'$N=6$, $\Lambda = 4$, $W =\frac{-1.7}{(z+1.3)}$, $V = 0.8e^{-0.6z}$, $e_d = -2.1$, $U=1.9$', size=14,style='normal')

teste = np.loadtxt('0_Energies_R_500.txt')
Nz = 800
L = 8.75
dz = L/Nz
Ne = len(teste)
Ne = 35
V0 = 0.81
z  = np.ones(Ne)
Gamma = np.zeros(Nz+1)
Colors = ['black','blue','purple','red','orange','green','yellow','navy','pink','maroon','grey','gold','black','blue','purple','red','orange','green','black']

E_0 = 2.715 + 0.1

E_P = (teste[0] + 0.15 )*np.ones(Nz+1)
E_M = (teste[0] - 0.15 )*np.ones(Nz+1)
z2 = np.zeros(Nz+1)
for i in range (0,Nz+1):
    z2[i] = i*dz

for i in range (0,Nz+1): 
    a = np.loadtxt(f'0_Energies_R_{int(i)}.txt')
    z = i*dz*np.ones(Ne)
    for j in range(0,Ne):
        line= ax1.plot(z[j],a[j]+E_0)
        setp(line, linestyle='solid',color=Colors[1%12], marker='s', markeredgewidth=0.5, markersize=0.5, markevery=1)

#line= ax1.plot(z2[:],E_M[:])
#setp(line, linestyle='solid',color=Colors[0], marker='none', linewidth=0.1, markeredgewidth=0.1, markersize=0.1, markevery=1)

#line= ax1.plot(z2[:],E_P[:])
#setp(line, linestyle='solid',color=Colors[0], marker='none', linewidth=0.1, markeredgewidth=0.1, markersize=0.1, markevery=1)

ax1.set_ylabel(r'$\langle \varphi_n | H_e(z) | \varphi_n \rangle /D$', size=22,style='normal')
ax1.set_xlabel(r'$z$', size=25,style='normal')

ax1.tick_params(which='major',direction='in', axis='y',labelsize=labelsize, length=tickssize, width=1 )
ax1.tick_params(which='minor',direction='in', axis='y',labelsize=labelsize, length=tickssize/2, width=0.5)
ax1.tick_params(which='major',direction='in', axis='x',labelsize=labelsize, length=tickssize, width=1, pad=6 )
ax1.tick_params(which='minor',direction='in', axis='x',labelsize=labelsize, length=tickssize/2, width=0.5)
#ax1.legend()

ax1.set_xlim(-0.1,9.01)
ax1.set_ylim(-3.00,2.0)

ax1.minorticks_on()
ax1.xaxis.set_major_locator(MultipleLocator(1))
ax1.yaxis.set_major_locator(MultipleLocator(1))

savefig(out_file_name)
