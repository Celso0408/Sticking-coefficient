#include "mel.h"
// This function will salve somes bigs matrixs for the NRG code. 
// 

static double **mel_; 								        //|Q+1 r'|f_(N)^+|Q r|
static double **eigen_erg_;							        //|Q dS r'|H_{N}|Q s r|
static double **eigen_vect_;							        //|Q dS r'|Q dS p'| 

static double **mel2_; 								        //|Q+1 r'|f_(N)^+|Q r|
static double **eigen2_erg_;							        //|Q dS r'|H_{N}|Q s r|
static double **eigen2_vect_;							        //|Q dS r'|Q dS p'| 

static double** projection_;
static double** projection_p_;

static double** ND_;
static double** ND_p_;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 			       |Q+1 r'|f_(N)^+|Q r| 
//This function starts the mel matrix.
void mel_start(int N){
  int nq = (N + 2) +1;
  // Here i'm creating the pointer to save the sectors (Q)
  mel_ = new double*[nq];							
}

// MEL_ FUNCTIONS; 
// Here i'm allocating memory for the (Q) sector. I need delete and re-alloc memory every iteration. 
void mel_alloc_memory(int q, long nk){
  mel_[q] = new double[nk];							
}

// Functions to write and read in the matrix. 
void mel_write(int q, long k, double value){	
  mel_[q][k] = value;
}

double mel_read(int q, long k) {
  return mel_[q][k]; 
}

// Delete all elements from the matrix.
void mel_delete(int N, int *dimen){
  int nq = (N+2)+1; 																	  
  for(int q = 0; q < nq-1; q++){
	int dim  = dimen[q];
	int dim2 = dimen[q+1];
	if ((dim>0)&&(dim2>0)){
	    delete[] mel_[q];
	}
  }
  delete[] mel_;
  mel_ = NULL;
}


// 			       |Q+1 r'|f_(N)^+|Q r| 
//This function starts the mel matrix.
void mel2_start(int N){
  int nq = (N + 2) +1;
  // Here i'm creating the pointer to save the sectors (Q)
  mel2_ = new double*[nq];							
}
// MEL2_ FUNCTIONS; 
// Here i'm allocating memory for the (Q) sector. I need delete and re-alloc memory every iteration. 
void mel2_alloc_memory(int q, long nk){
  mel2_[q] = new double[nk];							
}

// Functions to write and read in the matrix. 
void mel2_write(int q, long k, double value){	
  mel2_[q][k] = value;
}

double mel2_read(int q, long k) {
  return mel2_[q][k]; 
}

// Delete all elements from the matrix.
void mel2_delete(int N, int *dimen){
  int nq = (N+2)+1; 																	  
  for(int q = 0; q < nq-1; q++){
	int dim  = dimen[q];
	int dim2 = dimen[q+1];
	if ((dim>0)&&(dim2>0)){
	    delete[] mel2_[q];
	}
  }
  delete[] mel2_;
  mel2_ = NULL;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 						EIGENVALUES AND EIGENVECTORS FUNCTIONS
void eigen_start(int N){
  int nq = (N + 2) +1;
  // Here i'm creating the pointer to save the sectors (Q)
  eigen_erg_  = new double*[nq];							
  eigen_vect_ = new double*[nq];					
}

void eigen_delete(int N, int *dimen){
  int nq = (N+2)+1; 								
  for(int q = 0; q < nq; q++){
		int dim  = dimen[q];
		if (dim>0){
			delete[] eigen_erg_[q];
		}
  }
  delete[] eigen_erg_;
  eigen_erg_  = NULL;
}

void eigen_vect_delete(int N, int *dimen){
  int nq = 1*(N+2)+1;													
  for(int q = 0; q < nq; q++){
		int dim  = dimen[q];
		if (dim>0){
			delete[] eigen_vect_[q];
		}
  }
  delete[] eigen_vect_;
  eigen_vect_ = NULL;
}

void eigen_erg_alloc_memory(int q, long nk){
  eigen_erg_[q] = new double[nk];							
}

void eigen_vect_alloc_memory(int q, long nk){
  eigen_vect_[q] = new double[nk];						
}

// Functions to write and read in the matrix of the EIGENVALUES. 

void eigen_erg_write(int q, long k, double value) {	
  eigen_erg_[q][k] = value;
}

double eigen_erg_read(int q, long k) {
  return eigen_erg_[q][k];
}

// Functions to write and read in the matrix of the EIGENVECTORS. 

void eigen_vect_write(int q, long k, double value) {	
  eigen_vect_[q][k] = value;
}

double eigen_vect_read(int q, long k) {
  return eigen_vect_[q][k];
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 						EIGENVALUES AND EIGENVECTORS FUNCTIONS
void eigen2_start(int N){
  int nq = (N + 2) +1;
  // Here i'm creating the pointer to save the sectors (Q)
  eigen2_erg_  = new double*[nq];							
  eigen2_vect_ = new double*[nq];					
}

void eigen2_delete(int N, int *dimen){
  int nq = (N+2)+1; 								
  for(int q = 0; q < nq; q++){
		int dim  = dimen[q];
		if (dim>0){
			delete[] eigen2_erg_[q];
		}
  }
  delete[] eigen2_erg_;
  eigen2_erg_  = NULL;
}

void eigen2_vect_delete(int N, int *dimen){
  int nq = 1*(N+2)+1;													
  for(int q = 0; q < nq; q++){
		int dim  = dimen[q];
		if (dim>0){
			delete[] eigen2_vect_[q];
		}
  }
  delete[] eigen2_vect_;
  eigen2_vect_ = NULL;
}

void eigen2_erg_alloc_memory(int q, long nk){
  eigen2_erg_[q] = new double[nk];							
}

void eigen2_vect_alloc_memory(int q, long nk){
  eigen2_vect_[q] = new double[nk];						
}

// Functions to write and read in the matrix of the EIGENVALUES. 

void eigen2_erg_write(int q, long k, double value) {	
  eigen2_erg_[q][k] = value;
}

double eigen2_erg_read(int q, long k) {
  return eigen2_erg_[q][k];
}

// Functions to write and read in the matrix of the EIGENVECTORS. 

void eigen2_vect_write(int q, long k, double value) {	
  eigen2_vect_[q][k] = value;
}

double eigen2_vect_read(int q, long k) {
  return eigen2_vect_[q][k];
}

////////////////////////////////////////////////////////Projections//////////////////////////////////////////////////////////////////////////////////
void projection_start(int N){
  int nq = (N+2) + 1;
  // Here i'm creating the pointer to save the sectors (Q,dS)
  projection_ = new double*[nq];													
}

// Here i'm allocating memory for the (Q,dS) sector. I need delete and re-alloc memory every iteration. 
void projection_alloc_memory(int q, long nk){
  projection_[q] = new double[nk];							
}

// Functions to write and read in the matrix. 
void projection_write(int q, long k, double value) {
  projection_[q][k] = value;
}
double projection_read(int q, long k) {
  return projection_[q][k];
}

// Delete all elements from the matrix.
void projection_delete(int N, int *dimen){
  int nq = (N+2) +1; 																
  for(int q = 0; q < nq; q++){
	int dim  = dimen[q];
	if (dim>0){
	    delete[] projection_[q];
	}
  }
  delete[] projection_;
  projection_ = NULL;
}

void save_projection(int N, int *dimen_){
  int nq = (N + 2) +1;						// Past nq
  projection_p_ = new double*[nq];								
  for(int q = 0; q < nq; q++){					
		int dim = dimen_[q];
		if (dim > 0){
			projection_p_[q] = new double[(long) dim*dim];
			for(long k = 0; k < (long) dim*dim; k++){
				projection_p_[q][k] = projection_read(q,k);
			}
		}	
  }		
}


double save_projection_read(int q, long k){
  return projection_p_[q][k];
}

void save_projection_delete(int N, int *dimen_){
  int nq = (N +2) +1; 														
for(int q = 0; q < nq; q++){
		int dim  = dimen_[q];
		if (dim>0){
			delete[] projection_p_[q];
		}
}
delete[] projection_p_;
projection_p_ = NULL;
}
