############################################################################################################################
############################################--- Dynamic of Atomic Collision---##############################################
############################################################################################################################
# export JULIA_NUM_THREADS=8 Put this in the terminal to change the number of threads to execute the code
############################################################################################################################
####################################################--- Importing ---#######################################################
############################################################################################################################
using LinearAlgebra							# Linear Algebra Package 
using Base.Threads							# 
BLAS.set_num_threads(8)							# 
############################################################################################################################
#########################################----Setting the collision parameters----###########################################
############################################################################################################################
const Nz = 800								# Number of Z points
const NeT= 35								# Total Number of Electronic states
const Ne = 35								# Number of Electronic states to work with <= NeT
const NeI= 1								# Initial Electronic state NeI <= Ne
const Lz = 8.75								# Size of the Box 
############################################################################################################################
################################################---- Initializing ----######################################################
############################################################################################################################
dz	= Float32(Lz/Nz)						# Space step
Energy_ = zeros(Float32,(Nz+1),Ne)					# Energy Levels
Int_Proj= zeros(Float32,Ne,Ne)						# Integral of the Proj.
Int_H= zeros(Float32,Ne,Ne)						# Integral of the Proj.

for z=1:1:(Nz+1)							# Build the Matrix (ok. Working!)
	Projections = zeros(Float32,NeT,NeT)
	file_t = open("0_Projections_"*string(z-1)*".txt")
	for i=1:1:(NeT)*(NeT)
		line 	= (i-1)÷(NeT) + 1
		collum	= i - (line-1)*NeT
		global x= parse(Float32,readline(file_t))
		Projections[line,collum] = x
	end
	close(file_t)
	E_elec = zeros(Float32,NeT,NeT)
	file_t = open("0_Energies_R_"*string(z-1)*".txt")
	for i=1:1:(NeT)
		global x= parse(Float32,readline(file_t))
		E_elec[i,i] = x
	end
	close(file_t)
	H_aux_z = Projections*E_elec*transpose(Projections)
	print("z = ",(z-1)*dz,"  Proj. :")
	for i=1:1:(Ne)
		print("<",NeI-1,"|",i-1, "> = ", Projections[NeI,i], "; ")
		global Energy_[z,i] += H_aux_z[i,i]
		Int_H[i,i] += (1/Lz)*dz*H_aux_z[i,i]
		for j=1:1:(Ne)
			if(i!=j)
				Int_Proj[i,j] += (1/Lz)*dz*((sin(500*(H_aux_z[j,j] - H_aux_z[i,i]))*H_aux_z[i,j])/( abs(H_aux_z[j,j] - H_aux_z[i,i]) + 0.000000001))^2
				Int_H[i,j]+= (1/Lz)*dz*abs(H_aux_z[i,j])
			end
		end
	end
	println(" ")
	println(" ")
end


file=open("BO_potentials.txt","w")	
	for z=1:1:(Nz+1)
		posi = (z-1)*dz						#
		write(file,string(posi),"	")			# 
		for i=1:1:Ne						#
			write(file,string(Energy_[z,i]),"	")	# 
		end							#
		write(file,"\n")					# 
	end								#
close(file)

file=open("Integral_Matrix_Fermi_Golden_Rule.txt","w")	
	for i=1:1:Ne
		write(file," Ne = ",string(i), "\n")
		for j=1:1:Ne
			if(Int_Proj[i,j] < 0.01)
				Int_Proj[i,j] = 0
			end
			write(file,string(j),"	",string(Int_Proj[i,j]),"\n")# 
		end
		write(file,"\n")
	end
close(file)

file=open("Integral_H.txt","w")	
	for i=1:1:Ne
		for j=1:1:Ne
			write(file,string(Int_H[i,j]),"\n")# 
		end
	end
close(file)

