#include "param.h"
#include <iomanip>
#include "iterd.h"
#include "iterd_2.h"
#include "iterN.h"
#include "iterN_2.h"
using namespace std;

static int *dimen_p;								// Number of basis on the (Q)_{N-1} sector.
static int *dimen;								// Number of basis on the (Q)_N sector.

int main(){

int N_max = fN_max();								// Maximum number of iterations;

std::cout << "Starting the NRG code..." << std::endl;
std::cout << std::endl;
std::cout << std::setprecision(10) << std::fixed;
read_all_params();    								// Read the parameters to start the code.
int Nz = 800;
double L = 8.75;
double L0=  L;
double r = 1.67; //1.67
double z_im = 1.0;
double V0 = 1.62;
double K_0 = -1.62;

double dz = (double) L/Nz;

for(int z = 0; z <= Nz; z++){
double W1 = K_0/(L0+z_im);
double V1 = V0*exp(-L0/r);
double W2 = K_0/(z*dz+z_im);
double V2 = V0*exp(-z*dz/r);

int nq = (2+0)+1; 								// Total number of possibles q in N=0. 

dimen_p = new int[nq];
for(int i=0; i< nq; i++){
		dimen_p[i] = 0;
	}
iter0_1(dimen_p, V1, W1);            							// Initial condictions for "Left Side" N = 0;
iter0_2(V2, W2);								// Initial condictions for "Right Side" N = 0;
//Matrix |Q' dS' r'|f_N^+|Q dS r|: N = 0;
//Eigenvalues: |Q dS r|H_N|Q dS r|: N = 0;
//EigenVectors: |Q dS r||Q dS p|: N = 0;
//Dim(0);

for(int ni = 1; ni <= N_max; ni ++){   
	nq = (ni+2)+1; 		          						         // Total number of possibles q. 
	dimen = new int[nq]; 							                 // Matrix to save the basis in the Left sector.
	for(int i=0; i< nq; i++){
	    dimen[i] = 0;
	}

	iterN_1(ni, dimen_p, dimen, z);					      	                 // Solve the 'Left Side' hamiltonian for N=ni
	iterN_2(ni, dimen_p, dimen, z);						                 // Solve the 'Right Side' hamiltonian for N=ni

	nq = (ni-1+2)+1; 							                 // Delete the dimen_p matrix. 
	delete[] dimen_p;
	dimen_p = NULL;
	dimen_p = dimen;								         // Left: New imput of number of basis
										 
	std::cout << "Done! Iteraction " << ni <<  " complete! " << z  << std::endl;
}
        delete[] dimen;
	dimen_p = NULL;
	dimen = NULL;
}
return 0;
}
