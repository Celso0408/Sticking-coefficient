#include "iterN_2.h"

static int *NS_;
static int *NN_;

// Populating the primitive base; 
void Populate(int N, int *dimen_){  // DIMEN = DIM(N-1);
int nq_past = (N-1+2)+1;
//computaional bases:
// Operations Sulth |Q  |_N <= 	|Q |_(N-1)
// Operations North |Q+1|_N <= 	|Q |_(N-1)
for(int q = 0; q < nq_past; q++){
		int dim = dimen_[q];
		NS_[q] += dim;
		NN_[q+1] += dim; 
}
}

// THE FUNCTION TO SOLVE THE ITERACTION N. 

void iterN_2(int N, int *dimen_p_, int *dimen_, int z){
//std::cout << "Diagonalization process for 'H2' N=" << N << " is starting now..."  << std::endl;

int nq = (N+2)+1;
// Creating the Basis and Making all matrix elements zero.
NS_ = new int[nq];
NN_ = new int[nq];
for(int i=0; i< nq; i++){
	NS_[i] = 0;
	NN_[i] = 0;
}

Populate(N, dimen_p_);

double lamb_ = lamb();								    	                                                        // Reading Lambda from parameters.txt.
double D_N = (1-pow(lamb_, (float) -1))*(pow(lamb_, (float) -(N-1)/2))/log(lamb_);	                                                        // D_N
double t_N = (1-pow(lamb_,(float) -N-2))/sqrt((1-pow(lamb_,(float) -2*(N-1)-1))*(1-pow(lamb_,(float) -2*(N-1)-3)));				// Calculating the coupling t_(N-1).

// Creating here the pointer to hamiltonian sector (q). 
double **HN_ = new double*[nq];

#pragma omp parallel for
for(int q = 0; q < nq; q++){
		int dim = NS_[q] + NN_[q];
		if (dim > 0){
			HN_[q] = new double[(long) (dim+1)*dim/2];			// Allocating memory to sector (q,ds).
                        for(int p2=0; p2 < dim; p2++){
			      for(int p1=0; p1<= p2; p1++){
				    int g1 = genre(q,p1+1, NS_, NN_);			        // g1(p1)
				    int g2 = genre(q,p2+1, NS_, NN_);			        // g2(p2)
                                    int q1 = find_charge(q,g1);                                
                                    int r1 = find_father(q,g1,p1+1,NS_);
                                    int q2 = find_charge(q,g2);                                
                                    int r2 = find_father(q,g2,p2+1,NS_);
                                    // std::cout << "|" << q << " , " << p2 << " , " << g2  << "| ... |" << q2 << " , " << r2 << " , " << g2 << "|" << std::endl;
                                    int dim1 = dimen_p_[q1];				
				    int dim2 = dimen_p_[q2];
				    long k_mel_1 = (r2-1)*dim1+(r1-1);
				    long k_mel_2 = (r1-1)*dim2+(r2-1); 
				    long k = (p2*(p2+1)/2) + p1; 			// Memory address starting in k=0;
                                    HN_[q][k] = 0; 
					if ((g1==g2)&&(q1==q2)&&(r1==r2)){			// Diagonal terms.
					  HN_[q][k]= sqrt(lamb_)*eigen2_erg_read(q1,(long) r1-1);  	// Att, scaled H
					}
					if ((g2==0)&&(g1==1)){						// SN terms.
					  HN_[q][k] = t_N*mel2_read(q1,k_mel_1);
					}
					if ((g2==1)&&(g1==0)){						// NS terms. 
					  HN_[q][k] = t_N*mel2_read(q2,k_mel_2);
					}					
                              }
                        }	
		} // end if dim> 0	
} // end for q

eigen2_delete(N-1,dimen_p_);  // Delete all elements saved in eigen matrix
mel2_delete(N-1,dimen_p_); // Delete all elements saved in mel

eigen2_start(N);
// Ok. The Hamiltonian is ready to diagonalization process. 
for (int q=0; q < nq; q++) {
		int dim = NS_[q]+ NN_[q];
		if(dim > 0) {
			double *eigen_values = new double[dim];                         	// Matrix to find the E-Energies
			double **eigen_vectors = new double*[dim];		               	// Matrix to find the E-Vectors
			for (int k=0; k<dim; k++) {
				eigen_vectors[k] = new double[dim];
			}
			long Nel_max = (1+dim)*dim/2;	                      		        // Maximum number of elements of LTM
			double* Hamiltonian  = new double[Nel_max];                     	// H[q] to use in diagonalization
			for (long k=0; k<Nel_max; k++) {					// Save the values to diagolize
				Hamiltonian[k] = HN_[q][k];
			}
			delete[] HN_[q];					        // Delete the HN in the sector (q)
			int ret = givens(dim, dim , Hamiltonian , eigen_values, eigen_vectors, 0);// Solve the hamiltonian
			delete[] Hamiltonian;
			Hamiltonian = NULL;										        
			eigen2_erg_alloc_memory(q,(long) dim);			                // Alloc memory to save E-Energies
			eigen2_vect_alloc_memory(q,(long) dim*dim);			        // Alloc memory to save E-Vectors
			for (long k=0; k < dim; k++) {
				eigen2_erg_write(q,k,eigen_values[k]);
			}
			for (int i=0; i < dim ; i++) {						// Line 0, 1... dim_cut_off
				int signal = 1;
				if (eigen_vectors[i][0] < 0){
					signal = -1;
				}
				else{
					if((eigen_vectors[i][0] == 0)&&(eigen_vectors[i][1]<0)){
						signal = -1;						
					}
				}
				for (int j=0; j<dim; j++) { 					// Collum 0, 1 ... dim
					eigen2_vect_write(q,(long) i*dim+j, (double) signal*eigen_vectors[i][j]); 
				}
				
			}
			delete[] eigen_values;
			eigen_values = NULL;
			for (int i=0; i< dim; i++) {
				delete[] eigen_vectors[i];
			}
			delete[] eigen_vectors;
			eigen_vectors= NULL;
		} //end if dim > 0
} // end for q
delete[] HN_;
HN_ = NULL;

// Printing the eigen energies and eigen vectors
std::cout << std::setprecision(12) << std::fixed;
for (int q=0; q < nq; q++) {
		int dim = dimen_[q];
		if((dim > 0)&&(q== (int) (N+4)/2 )) {
			//std::cout << "["<< q << "] Sector"<< '\t' <<"dim ="<< dim;
			//std::cout << ";  Eigen values (Escaled): ";
			//for (long k=0; k<dim; k++) {
			//	double Energy = D_N*eigen2_erg_read(q,k);
			//	std::cout << "E[" << k+1 << "]=";
			//	std::cout << Energy << ";";       // Scaled results         
			//}
                        if (N == fN_max()){
				std::ofstream file2;
				file2.open("0_Energies_R_"+std::to_string(z)+".txt");
				//Saving the Energies 
				for (long k=0; k<dim; k++) {
					double Energy = E_d() + D_N*(eigen2_erg_read(q,k));        
					file2 << std::setprecision(18) << Energy;
					file2 << std::endl;
				}
  				//Closing the file
  				file2.close();
			}
			/*  Printing The Vectors.
			std::cout << std::endl << "Eigen vectors matrix:" << std::endl;
			for (int i=0; i<dim; i++) {
				std::cout << '\t';
				for (int j=0; j<dim_t; j++) {
					long k =i*dim +j;
					double vector = eigen_vect_read(q,ds,k);
					std::cout << vector << "; ";
				}
				std::cout << std::endl;
			}
			// */                        
			std::cout << std::endl;
		}// end if dim>0
}//end for q

if(N < fN_max()){

mel2_start(N);
//|Q+1 dS+1 r2|(f_N^+)|Q dS r1| = sum_{p2,p1} U*(Q+1;dS+1)[r2,p2]U(Q;S)[r1,p1]*|Q+1 dS+1 p2|(f_N^+)|Q dS p1|
for(int q=0;q<(nq-1);q++){
		int dim = dimen_[q];
		int dim2 = dimen_[q+1]; 
		if (dim*dim2>0){
			int N11 = NS_[q];		// Sup limit for g1 = 0
			int N12 = N11 + NN_[q]; 	// Sup limit for g1 = 1
			int N21 = NS_[q+1];             // Sup Limit for g2 = 0
			int N22 = N21 + NN_[q+1];	// Sup Limit for g2 = 1
			mel2_alloc_memory(q,(long) dim*dim2);						// 
			#pragma omp parallel for
			for(long k=0;k<dim*dim2;k++){
				double sum = 0;
				int r2 = k/dim;      						// line
				int r1 = k - r2*dim; 						// Collum
				for(int p1=0; p1<N11; p1++){ 			// g1(p1) = 0;	// g2(p2) = 1;
					int p2 = p1 + N21;
					if (p2<N22){						// delta(l1,l2)
						double aux2=eigen2_vect_read(q+1,(long)r2*N22 +p2);
						double aux1=eigen2_vect_read(q,(long)r1*N12+p1);
						sum += aux2*aux1;
					}						
				}
				mel2_write(q,k,sum);
			} //end for k
		} // end if dim*dim2
} // end for q

}

// Projetcions Beteween the "Right" and "Left" sectors.
// Save the eigenvector in matrix here to acess more fast
double** vect_L_ = new double*[nq];								
double** vect_R_ = new double*[nq];
for(int q = 0; q < nq; q++){					
		int dim = dimen_[q];
		int dim2= NS_[q]+NN_[q];		
		if (dim > 0){
			vect_L_[q] = new double[(long) dim*dim2];
			vect_R_[q] = new double[(long) dim*dim2];
			for(long k = 0; k < (long) dim*dim2; k++){
				vect_L_[q][k] = eigen_vect_read(q,k);
				vect_R_[q][k] = eigen2_vect_read(q,k);
			}
		}
}		
eigen_vect_delete(N,dimen_); // Delete all elements saved in eigen matrix
eigen2_vect_delete(N,dimen_); // Delete all elements saved in eigen matrix


// Save the past projection matrix 
double** projection_past_ = new double*[nq-1];								
for(int q = 0; q < nq-1; q++){					
		int dim = dimen_p_[q];		
		if (dim > 0){
			projection_past_[q] = new double[(long) dim*dim];
			for(long k = 0; k < (long) dim*dim; k++){
				projection_past_[q][k] = projection_read(q,k);
			}
		}	
}		
projection_delete(N-1, dimen_p_);       // Delete the projection matrix from the iteraction N-1
projection_start(N);                    // Starting the adress in the sector (q, ds) to save the matrix projection


for(int q=0; q<nq; q++){
		int dim = dimen_[q];
		if(dim> 0){
			int N1 = NS_[q];				  			        // Sup limit for g1 = 0
			int N2 = N1 + NN_[q]; 							        // Sup limit for g1 = 1
			projection_alloc_memory(q, (long) dim*dim);
			#pragma omp parallel for
			for(long k = 0; k < dim*dim; k++){
			      double sum = 0;
			      int r_L = k/dim;						                // Line
			      int r_R = k - r_L*dim;						        // Colum
			      #pragma omp parallel for
			      for(int p_L = 0; p_L < N1 ; p_L ++){				        // g1 = 0 
			      for(int p_R = 0; p_R < N1; p_R ++){			                // g2 = 0
				    sum += vect_L_[q][(long)r_L*N2 +p_L]*vect_R_[q][(long) r_R*N2 +p_R]*projection_past_[q][(long)(p_L)*dimen_p_[q] +p_R];
			      }}
			      #pragma omp parallel for
			      for(int p_L = N1; p_L < N2; p_L ++){				        // g1 = 1
			      for(int p_R = N1; p_R < N2; p_R ++){			                // g2 = 1
				    sum += vect_L_[q][(long)r_L*N2 +p_L]*vect_R_[q][(long) r_R*N2 +p_R]*projection_past_[q-1][(long)(p_L-N1)*dimen_p_[q-1]+p_R-N1]; 
			      }}
			//matrix_to_save[k] = sum;
			projection_write(q,k,sum);
			} // end for k
		}// end if dim > 0
} // end for q

// Printing the projections in the last interaction
if (N == fN_max()){

std::ofstream file3;
file3.open("0_Projections_"+std::to_string(z)+".txt");
for(int q=0; q<nq; q++){
		int dim = dimen_[q];
		if((dim > 0)&&(q == (int) (N+4)/2 )){
			for(int r_L = 0; r_L < dim; r_L++){						// Line /left side
				for(int r_R = 0; r_R < dim; r_R++){					// Column /Right side
					long k = r_L*dim + r_R;						
					double sum = projection_read(q,k);
					//std::cout <<"Proj["<<q-N-2<<";"<< ds<<"]("<<r_L + 1 << ";" <<r_R + 1 << ") = "; 
					//std::cout << sum << "; ";
					file3 << std::setprecision(18) << sum;
					file3 << std::endl;						  
				}
				//file3 << std::endl;
			} // end for k
		} // end if dim > 0
} // end for q
file3.close();

eigen_delete(N,dimen_);
eigen2_delete(N,dimen_);
projection_delete(N, dimen_);

} // end if N==N_max


// Delete the eigenvalues matrix
for(int q = 0; q < nq; q++){
		int dim  = dimen_[q];
		if (dim>0){
			delete[] vect_R_[q];
			delete[] vect_L_[q];
		}
}
delete[] vect_R_;
delete[] vect_L_;
vect_R_ = NULL;
vect_L_ = NULL;

// Delete the past projection matrix
for(int q = 0; q < nq-1; q++){
		int dim  = dimen_p_[q];
		if (dim>0){
			delete[] projection_past_[q];
		}
}
delete[] projection_past_;
projection_past_ = NULL;



delete[] NS_;
delete[] NN_;
NS_ = NULL;
NN_ = NULL;


}
