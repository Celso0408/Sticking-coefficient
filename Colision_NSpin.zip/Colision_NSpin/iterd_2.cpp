#include "iterd_2.h"

static int *NS_;
static int *NN_;

void iter0_2(double V, double W){  // {Cd,f0} 

int nq = 3; // Possible number of particles : {0,1,2}

// Creating the Basis and Making all matrix elements zero.
NS_ = new int[nq];
NN_ = new int[nq];
for(int i=0; i< nq; i++){
	NS_[i] = 0;
	NN_[i] = 0;
}
// Completing the Bases for N= 0
//Numeric Basis           Analytical Basis
//{|[Qn]|}                {|Q p|};
 NS_[0] = 1; // vacuum    |0 1|
 NS_[1] = 1; // Cd        |1 1| 
 NS_[2] = 0; // 
 NN_[0] = 0; // 
 NN_[1] = 1; // f0        |1 2|
 NN_[2] = 1; // f0Cd      |2 1|

// Matrix to Build the Hamiltonian 
double **H0_ = new double*[nq];
for(int q = 0; q < nq; q++){
	H0_[q] = new double[3];
	for(int k=0; k < 3; k++){
	    H0_[q][k] = 0;
	}	
}

double lamb_ = lamb();  								// Lambda
double D_0   = 1*(1-pow(lamb_,(float)-1))*(pow(lamb_,(float) 1/2))/log(lamb_);		// D_0


double Wz = (-1*(exp(1/W) + exp(-1/W))/(exp(-1/W) - exp(1/W)) + 1);                       //
double E_0_ = E_0()*D_0;                                                                //

H0_[0][0] = 0;                                                     // vacuum

H0_[1][0] = E_d() +U() + W + E_0_;                                 // H c_d^+ | 0>
H0_[1][1] = V;                                                     // Coupling
H0_[1][2] = -0.05;                                                  // H f_0^+ |0>

H0_[2][0] = E_d() +U() + W + W + E_0_;                             // H c_d^+ f_0^+ |0> 

eigen2_start(0);

// Finding the Bases that diagonalize the Hamiltonian and the eigenvalues for each Base.
// Solving the Hamiltonian for N= 0 using the functions givens;
//std::cout << "Diagonalization process for  'H2' N = 0 is starting now...." << std::endl<< std::endl;
for (int q=0; q < nq; q++) {
	int dim = NS_[q] + NN_[q];
	if(dim > 0) {
	    eigen2_erg_alloc_memory(q, (long) dim);  //check
	    eigen2_vect_alloc_memory(q, (long) dim*dim); //check
	    double *eigen_values = new double[dim];	            		        // Matrix to calculate E-Values
	    double **eigen_vectors = new double*[dim];	  			        // Matrix to calculate E-Vectors
	    for (int k=0; k<dim ; k++) {
		  eigen_vectors[k] = new double[dim];
	    }
	    int Nel_max = (1+dim)*dim/2;                                                // Maximum number of elements in LTM
	    double *Hamiltonian = new double[Nel_max];             		        // Change the size
	    for (int k=0; k<Nel_max; k++) {					        // Saving the values to diagolize
		    Hamiltonian[k]= H0_[q][k]/D_0;		                        // Att, scaled hamiltonian.
	    }
	    givens(dim, dim , Hamiltonian , eigen_values, eigen_vectors, 1); 	        // Solving the H
	    delete[] Hamiltonian;
	    Hamiltonian = NULL;
	    for (long k=0; k<dim; k++) {
		    eigen2_erg_write(q,k,eigen_values[k]);	//check        	        // Saving the eigenvalues
	    }
	    delete[] eigen_values;
	    eigen_values = NULL; 	
	    for (int i=0; i<dim; i++) {
	        for (int j=0; j<dim; j++) {
		    long k =i*dim +j;
		    eigen2_vect_write(q,k,eigen_vectors[i][j]);   //check               // Saving the eigenvectors
		}
		delete[] eigen_vectors[i];	
	    }
	    delete[] eigen_vectors;
	    eigen_vectors = NULL;
	}// end if dim>0
	delete[] H0_[q]; 
}//end for q
delete[] H0_;
H0_ = NULL;

// Printing the eigen energies and eigen vectors
//std::cout << "Fundamental Energy (Non Escaled) for N = 0:" << '\t' << D_0*E_f << std::endl<< std::endl;
for (int q=0; q < nq; q++) {
		int dim = NS_[q] + NN_[q];
		if(dim > 0) {
                        //std::cout << "["<< q << "] Sector" <<'\t'<<"dim ="<< dim << std::endl;
			//std::cout << "Eigen values (Non Scaled):";
                        //for (long k=0; k<dim; k++) {
			//	double Energy = eigen2_erg_read(q,k);       	
		        //	std::cout << D_0*Energy << ";";          
		        //}
			/*
			std::cout << std::endl << "Eigen vectors matrix:" << std::endl;
			for (int i=0; i<dim; i++) {
				std::cout << '\t';
				for (int j=0; j<dim; j++) {
					long k =i*dim +j;
					double vector = eigen_vect_read(q,k);
					std::cout << vector << ";" <<'\t';
				}
				std::cout << std::endl;
			}
			// */
			//std::cout << std::endl<< std::endl;
		}// end if dim>0
}//end for q

mel2_start(0);


//|Q+1 r2|(f0^+)|Q r1| = sum_{p2,p1} U*(Q+1)[r2,p2]U(Q)[r1,p1]*|Q+1 p2|(f0^+)|Q p1|
for(int q=0;q<(nq-1);q++){
		int dim = NS_[q] + NN_[q];
		int dim2 = NS_[q+1] + NN_[q+1];
		if ((dim>0)&&(dim2>0)){
			mel2_alloc_memory(q,(long) dim*dim2);						// 
			for(long k=0; k < (long) dim*dim2; k++){
				double sum = 0;
				double term= 0;
				int r2 = k/dim;      // line
				int r1 = k - r2*dim; // Collum
					for(int p1=0; p1<dim; p1++){
						for(int p2=0; p2<dim2; p2++){
							term = 0; 
							int g1 = genre(q,p1+1,   NS_, NN_);    	 	// What is the genre p1? 
							int g2 = genre(q+1,p2+1, NS_, NN_);		// What is the genre p2?
                                                  	if ((g1==0)&&(g2==1)){term = 1;}	                                                        
							double aux2 = eigen2_vect_read(q+1,(long) r2*dim2 +p2);
							double aux1 = eigen2_vect_read(q, (long) r1*dim +p1);
							sum = sum + term*aux2*aux1;
						}
					}
			       mel2_write(q,k,sum);
			}
		}
}
/*
for(int q=0;q<(nq-1);q++){
		int dim = NS_[q] + NN_[q];
		int dim2 = NS_[q+1] + NN_[q+1];
		if ((dim>0)&&(dim2>0)){
                for(long k=0; k < (long) dim*dim2; k++){
				int r2 = k/dim;      // line
				int r1 = k - r2*dim; // Collum
                                std::cout<<"|"<<q+1<<","<< r2<<"|"<<"f_0^+"<<"|"<<q<<","<<r2<<"|"<<" = "<< mel_read(q,k)  << std::endl;
                }}
}
// */

projection_start(0);

for(int q=0; q<nq; q++){
		int dim = NS_[q] + NN_[q];
		if(dim> 0){
			projection_alloc_memory(q, (long) dim*dim);
			for(long k = 0; k < dim*dim; k++){
				double sum = 0;
				int r_l = k/dim;				         // Line
				int r_r = k - r_l*dim;					// Colum
				for(int p = 0; p < dim; p++){
					double aux_l = eigen_vect_read(q, (long) r_l*dim +p);
					double aux_r = eigen2_vect_read(q,(long) r_r*dim +p);
					sum = sum + aux_l*aux_r;
				}
				projection_write(q,k,sum);
				//std::cout <<"Proj["<<q<<"]("<<r_l + 1 << ";" <<r_r + 1 << ") = " <<'\t'; 
				//std::cout << projection_read(q,k) << std::endl;
			} // end for k
		} // end if dim > 0
} // end for q

delete[] NS_;
delete[] NN_;
NS_ = NULL;
NN_ = NULL;

} // end main function 
