#include <cstddef>

// Start both Matrix.  
void mel_start(int N);
void mel2_start(int N);

// MEL_ Functions.  
void mel_alloc_memory(int q, long nk);
void mel_write(int q, long k, double value);
double mel_read(int q, long k);
void mel_delete(int N, int *dimen);
// MEL_ Functions.  
void mel2_alloc_memory(int q, long nk);
void mel2_write(int q, long k, double value);
double mel2_read(int q, long k);
void mel2_delete(int N, int *dimen);


// EIGEN Functions. 
void eigen_start(int N);
void eigen_delete(int N, int *dimen);
void eigen_vect_delete(int N, int *dimen);
void eigen_erg_alloc_memory(int q, long nk);
void eigen_vect_alloc_memory(int q, long nk);
void eigen_erg_write(int q, long k, double value);
double eigen_erg_read(int q, long k);
void eigen_vect_write(int q, long k, double value);
double eigen_vect_read(int q, long k);

// EIGEN Functions. 
void eigen2_start(int N);
void eigen2_delete(int N, int *dimen);
void eigen2_vect_delete(int N, int *dimen);
void eigen2_erg_alloc_memory(int q, long nk);
void eigen2_vect_alloc_memory(int q, long nk);
void eigen2_erg_write(int q, long k, double value);
double eigen2_erg_read(int q, long k);
void eigen2_vect_write(int q, long k, double value);
double eigen2_vect_read(int q, long k);

// Projection functions
void projection_start(int N);
void projection_alloc_memory(int q, long nk);
void projection_write(int q, long k, double value);
double projection_read(int q, long k);
void projection_delete(int N, int *dimen);
void save_projection(int N, int *dimen_);
double save_projection_read(int q, long k);
void save_projection_delete(int N, int *dimen_);
