#include <cmath>
#include "param.h"
#include "giv0.h"
#include "mel.h"
#include <new>

void iter0_1(int *DIMEN, double V, double W);
int genre(int q, int p, int *NS_, int *NN_);
