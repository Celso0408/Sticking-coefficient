// param.h
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string>
#include <iterator>
#include <regex>

double read_param(std::string var);
int write_param(std::string var, float var_value);
int update_parameters();
void read_all_params();
double lamb();
double U();
int fN_max();
double E_d();
double V_0();
double W_1();
double W_2();
double E_0();
